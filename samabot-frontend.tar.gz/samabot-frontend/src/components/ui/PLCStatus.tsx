"use client";
import { useState, useEffect } from "react";
import { apiService, type PLCStatus } from "../../services/api";

export default function PLCStatus() {
  const [status, setStatus] = useState<PLCStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        setLoading(true);
        const data = await apiService.getStatus();
        setStatus(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error desconocido');
        console.error('Error fetching PLC status:', err);
      } finally {
        setLoading(false);
      }
    };

    // Cargar estado inicial
    fetchStatus();

    // Actualizar cada 2 segundos
    const interval = setInterval(fetchStatus, 2000);

    return () => clearInterval(interval);
  }, []);

  const getConnectionColor = (quality: string) => {
    switch (quality) {
      case 'connected':
        return 'text-green-400';
      case 'disconnected':
        return 'text-red-400';
      case 'reconnecting':
        return 'text-yellow-400';
      default:
        return 'text-gray-400';
    }
  };

  const getConnectionIcon = (quality: string) => {
    switch (quality) {
      case 'connected':
        return '🟢';
      case 'disconnected':
        return '🔴';
      case 'reconnecting':
        return '🟡';
      default:
        return '⚪';
    }
  };

  if (loading) {
    return (
      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-600 rounded-lg p-4">
        <div className="text-center text-gray-300">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400 mx-auto mb-2"></div>
          Conectando al PLC...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-900/30 border border-red-500/50 rounded-lg p-4">
        <div className="text-center text-red-300">
          <div className="text-xl mb-2">⚠️</div>
          Error de conexión: {error}
        </div>
      </div>
    );
  }

  if (!status) {
    return (
      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-600 rounded-lg p-4">
        <div className="text-center text-gray-300">
          No hay datos disponibles
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-600 rounded-lg p-4 space-y-4">
      {/* Estado de conexión */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-2xl">{getConnectionIcon(status.connectionQuality)}</span>
          <span className={`font-mono ${getConnectionColor(status.connectionQuality)}`}>
            PLC {status.connectionQuality.toUpperCase()}
          </span>
        </div>
        <div className="text-sm text-gray-400">
          IP: {status.ip}
        </div>
      </div>

      {/* Entradas digitales */}
      <div>
        <h3 className="text-lg font-mono text-purple-400 mb-2">Entradas Digitales</h3>
        <div className="grid grid-cols-7 gap-2">
          {Object.entries(status.inputs).map(([name, value]) => (
            <div
              key={name}
              className={`p-2 rounded text-center text-sm font-mono ${
                value ? 'bg-green-600/30 border border-green-500/50' : 'bg-gray-700/30 border border-gray-600'
              }`}
            >
              <div className="text-xs text-gray-400">{name}</div>
              <div className={value ? 'text-green-400' : 'text-gray-500'}>
                {value ? 'ON' : 'OFF'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Salidas digitales */}
      <div>
        <h3 className="text-lg font-mono text-purple-400 mb-2">Salidas Digitales</h3>
        <div className="grid grid-cols-5 gap-2">
          {Object.entries(status.outputs).map(([name, value]) => (
            <div
              key={name}
              className={`p-2 rounded text-center text-sm font-mono ${
                value ? 'bg-blue-600/30 border border-blue-500/50' : 'bg-gray-700/30 border border-gray-600'
              }`}
            >
              <div className="text-xs text-gray-400">{name}</div>
              <div className={value ? 'text-blue-400' : 'text-gray-500'}>
                {value ? 'ON' : 'OFF'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Entradas analógicas */}
      <div>
        <h3 className="text-lg font-mono text-purple-400 mb-2">Entradas Analógicas</h3>
        <div className="grid grid-cols-2 gap-4">
          {Object.entries(status.analogInputs).map(([name, value]) => (
            <div key={name} className="bg-gray-700/30 border border-gray-600 rounded p-3">
              <div className="text-xs text-gray-400 mb-1">{name}</div>
              <div className="text-lg font-mono text-orange-400">
                {value.toFixed(1)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Alarmas */}
      {status.alarms.length > 0 && (
        <div>
          <h3 className="text-lg font-mono text-red-400 mb-2">⚠️ Alarmas Activas</h3>
          <div className="space-y-2">
            {status.alarms.slice(0, 3).map((alarm, index) => (
              <div key={index} className="bg-red-900/30 border border-red-500/50 rounded p-2">
                <div className="text-sm text-red-300">{alarm.message}</div>
                <div className="text-xs text-red-400">
                  {new Date(alarm.timestamp * 1000).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Información adicional */}
      <div className="text-xs text-gray-400 text-center">
        Última actualización: {new Date(status.lastUpdate * 1000).toLocaleTimeString()}
      </div>
    </div>
  );
} 