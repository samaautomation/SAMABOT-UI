import * as React from "react";

export default function SamitaPanel() {
  return (
    <div className="flex flex-col w-full h-full p-1 sm:p-2 md:p-4 overflow-hidden">
      {/* Samita AI - Emoji responsivo */}
      <div className="flex-1 flex items-center justify-center w-full overflow-hidden">
        <div className="w-full h-full flex items-center justify-center">
          <div className="text-center">
            <div className="text-6xl sm:text-8xl md:text-9xl mb-4 animate-pulse">
              🤖
            </div>
            <div className="text-2xl sm:text-3xl md:text-4xl text-purple-400 font-mono animate-bounce">
              SAMITA AI
            </div>
          </div>
        </div>
      </div>
      
      {/* Texto de estado ABAJO - pegado al logo */}
      <div className="text-center mt-2 sm:mt-3 md:mt-4">
        <div 
          className="text-base sm:text-lg md:text-xl lg:text-2xl font-mono text-purple-400"
          style={{
            marginLeft: '-0.5rem',
            fontSize: '1.25rem',
            transform: 'scaleY(1.1) scaleX(0.9)',
            letterSpacing: '0.05em'
          }}
        >
          SAMITA AI
        </div>
        <div className="text-xs sm:text-sm md:text-base lg:text-lg text-gray-300 px-1 sm:px-2">
          Sistema de Monitoreo Industrial
        </div>
      </div>
    </div>
  );
} 